﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Configuration;
namespace Swinney
{
    public partial class studenthome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT * from items", conn);
            SqlDataReader myReader = cmd.ExecuteReader();

            if (myReader.HasRows)
            {
                myReader.Read();
                TextBox2.Text = myReader["available"].ToString();
                myReader.Read();
                TextBox3.Text = myReader["available"].ToString();
                myReader.Read();
                TextBox4.Text = myReader["available"].ToString();
                myReader.Read();
                TextBox12.Text = myReader["available"].ToString();
                myReader.Read();
                TextBox13.Text = myReader["available"].ToString();
                myReader.Read();
                TextBox14.Text = myReader["available"].ToString();
                myReader.Read();
                TextBox5.Text = myReader["available"].ToString();
                myReader.Read();
                TextBox6.Text = myReader["available"].ToString();
                myReader.Read();
                TextBox7.Text = myReader["available"].ToString();
                myReader.Read();
                TextBox10.Text = myReader["available"].ToString();
                myReader.Read();
                TextBox11.Text = myReader["available"].ToString();
            }
            else
            {
                Console.Write("1");
            }
           
        }
    }
}